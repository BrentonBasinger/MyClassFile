'''
Title: Module 05
Dev: Brneton Basinger
Date:11/05/16
ChangeLog: (Who, When, What): none yet
'''


#1. Create a text file called Todo.txt using the following data:
#Clean House,low
#Pay Bills,high

#2. When the program starts, load each row of data from the ToDo.txt text file 
#into a Python dictionary. (The data will be stored like a row in a table.)
#I decided to use pandas so I could practice reading and writing to MS Excel. 

#This Library can be installed by using PIP Install pandas

#This imports the pandas library 
import pandas as pd

# Import the excel file and call it Task_List.xlsx
xls_file = pd.ExcelFile('Task_List.xlsx')

# This parses the data contained on Sheet1 of the MS Excel spreadsheet
df = xls_file.parse('Sheet1')

#Welcome the user:
print("\n\n\n Welcome to Brenton\'s Task List Program! \n\n\n\n")
 
# This prints out the items on the Task_List.xlsx                                                                                              
print(df)

#Start while loop to show menu after each step
while(True):
    #print the menu of options 
    print("\n\n\n\n\t Menu ")
    print("1) Display the items on your Task List \n")
    print("2) Add a Task to the list. \n")
    print("3) Remove a Task from the list. \n")
    print("4) Save changes to Task_List.xlsx in MS Excel and Exit Program \n\n")

    Choice = str(input("Select the action you wish to perform [1 - 4]: "))
    print("\n\n")
 
#Print the list if Option 1 is selected:   
    if (Choice.strip() == '1'):
        print(df)
        continue
 
#Add a new Task to the list   
    elif (Choice.strip() == '2'):
        print("\n\n")
        TaskD = str(input("Please enter the Task you would like to add: ")).strip()
        print("\n")    
        TaskP = str(input("Please enter a priority for this Task [Low/High] :  "))\
        .strip()
        print("\n\n")        
        df2 = pd.DataFrame({"Task" : [str(TaskD)], "Priority": [str(TaskP)]})
        df3 = df.append(df2, ignore_index=True)
        df3 = df3[["Task", "Priority"]]
        print("\n\n")
        df3.reset_index()
        print(df3)    
        df = df3
        continue

#Remove a Task from the List    
    elif(Choice.strip() == '3'):
        TaskRMV = input("Which Task number would you like to Remove? : ")
        print("\n\n")
        #df3.reset_index()
        df4 = df.drop(df.index[str(TaskRMV)])
        print("Task " + TaskRMV + " has been sucessfully removed fror the list! \n\n")         
        #print(df4)
        df=df4
        print(df)
        continue

#Save the Task list to Task_List.xlsx and Exit    
    elif(Choice.strip() == "4"):
        writer = pd.ExcelWriter('Task_List.xlsx', engine='xlsxwriter')
        df.to_excel(writer, sheet_name='Sheet1', index=False)
        worksheet = writer.sheets['Sheet1']
        workbook = writer.sheets['Sheet1']
        worksheet.set_column('A:B', 18)
        writer.save()
        print("Task_List.xlsx has been saved sucessfully! \n\n")
        print("Good Bye!")
        break

#Handle error if user enters an invalid option    
    elif(Choice.strip() != "4", "3", "2", "1"):
        print("Sorry! - That is not a valid option [1-4] Please try again")
        continue